// Listen for the submit button click event
document.querySelector('button[name="submit"]').addEventListener('click', () => {
    const umami = parseInt(document.querySelector('#umami').value);
    const sweetness = parseInt(document.querySelector('#sweetness').value);
    const astringency = parseInt(document.querySelector('#astringency').value);
    const vegetal = parseInt(document.querySelector('#vegetal').value);
    const aromatic = parseInt(document.querySelector('#aromatic').value);
    const grade = document.querySelector('#grade').value;
    const price = document.querySelector('input[name="price"]:checked')?.value;
    
    // Matching logic for the preset ideal combination and other cafés
    if (
      umami === 5 &&
      sweetness === 3 &&
      astringency === 2 &&
      vegetal === 3 &&
      aromatic === 3 &&
      grade === 'ceremonial' &&
      price === 'worth'
    ) {
      const liquid = document.getElementById('liquidLayer');
      liquid.style.animation = 'none';
      void liquid.offsetWidth;
      liquid.style.animation = 'pourLiquid 3s ease-in-out forwards';
      document.getElementById('resultPopup').style.display = 'flex';
    } else if (
      umami === 4 &&
      sweetness === 3 &&
      astringency === 2 &&
      vegetal === 4 &&
      aromatic === 4 &&
      grade === 'ceremonial' &&
      price === 'medium'
    ) {
      showCafe("Kettl", "https://kettl.co");
    } else if (
      umami === 3 &&
      sweetness === 3 &&
      astringency === 3 &&
      vegetal === 3 &&
      aromatic === 4 &&
      grade === 'ceremonial' &&
      price === 'splurge'
    ) {
      showCafe("Sorate", "https://sorate.co");
    } else if (
      umami === 3 &&
      sweetness === 4 &&
      astringency === 1 &&
      vegetal === 3 &&
      aromatic === 4 &&
      grade === 'ceremonial' &&
      price === 'splurge'
    ) {
      showCafe("Nippon Cha", "https://nipponcha.com");
    } else if (
      umami === 3 &&
      sweetness === 3 &&
      astringency === 3 &&
      vegetal === 3 &&
      aromatic === 3 &&
      grade === 'ceremonial' &&
      price === 'medium'
    ) {
      showCafe("Kijitora", "#");
    } else if (
      umami === 3 &&
      sweetness === 3 &&
      astringency === 3 &&
      vegetal === 3 &&
      aromatic === 3 &&
      grade === 'ceremonial' &&
      price === 'medium'
    ) {
      showCafe("Isshiki", "#");
    } else if (
      umami === 3 &&
      sweetness === 3 &&
      astringency === 3 &&
      vegetal === 3 &&
      aromatic === 3 &&
      grade === 'ceremonial' &&
      price === 'medium'
    ) {
      showCafe("PPL", "#");
    } else if (
      umami === 5 &&
      sweetness === 5 &&
      astringency === 1 &&
      vegetal === 5 &&
      aromatic === 5 &&
      grade === 'ceremonial' &&
      price === 'worth'
    ) {
      showCafe("12 Matcha", "#");
    } else if (
      umami === 5 &&
      sweetness === 3 &&
      astringency === 1 &&
      vegetal === 5 &&
      aromatic === 5 &&
      grade === 'ceremonial' &&
      price === 'medium'
    ) {
      showCafe("Setsugekka", "#");
    } else if (
      umami === 3 &&
      sweetness === 3 &&
      astringency === 3 &&
      vegetal === 3 &&
      aromatic === 4 &&
      grade === 'ceremonial' &&
      price === 'medium'
    ) {
      showCafe("La Cabra", "#");
    } else {
      alert("No matching matcha found. Try adjusting your preferences!");
    }
  });
  
  // Function to close the popup when the close button is clicked
  function closePopup() {
    document.getElementById('resultPopup').style.display = 'none';
  }
  
  // Function to update the popup with café-specific information and show it
  function showCafe(name, link) {
    const liquid = document.getElementById('liquidLayer');
    liquid.style.animation = 'none';
    void liquid.offsetWidth;
    liquid.style.animation = 'pourLiquid 3s ease-in-out forwards';
  
    document.querySelector('.cup-text').innerHTML = `
      <h2>${name}</h2>
      <p><strong>Explore:</strong> ${name} matches your taste!</p>
      <a href="${link}" target="_blank">Visit Site →</a>
    `;
    document.getElementById('resultPopup').style.display = 'flex';
  }
  