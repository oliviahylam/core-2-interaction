window.location.href = "explore.html";
